<?php
class Aluno {
private $nome;
private $curso;
public function setNome ($n){
    $this->nome = $n;
}
public function getNome (){
    return $this-> nome;
}

public function setCurso ($c){
    $this-> curso = $c;
}
public function getCurso (){
    return $this-> curso;
}

}
?>
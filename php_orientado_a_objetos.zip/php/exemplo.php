
<html>
<meta charset="UTF-8">
<head>
<title>Exemplo de classe</title>
</head>
<body>
<?php

include "aluno.php";
 $al = new Aluno(); //instancia
 $al->setNome($_POST["nome"]);
 $al->setCurso($_POST["curso"]);
 echo "nome:" . $al ->getNome();
 echo"<br>";
 echo"curso:" . $al ->getCurso();
?>
</body>
</html>
